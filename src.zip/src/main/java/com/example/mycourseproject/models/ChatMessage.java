package com.example.mycourseproject.models;

import java.util.Date;

public class ChatMessage {
    public String senderID, receivedId, message, dateTime;
    public Date dateObject;
    public String conversationId, conversationName, conversationImage;
}
