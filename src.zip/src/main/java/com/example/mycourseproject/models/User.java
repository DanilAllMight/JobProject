package com.example.mycourseproject.models;

import java.io.Serializable;

public class User implements Serializable
{
    public String name, image, email, token, id;
}
