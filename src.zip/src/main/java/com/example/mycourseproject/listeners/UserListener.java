package com.example.mycourseproject.listeners;

import com.example.mycourseproject.models.User;

public interface UserListener {
    void onUserClicked(User user);
}