package com.example.mycourseproject.listeners;

import com.example.mycourseproject.models.User;

public interface ConversionListener {
    void onConversionClicked(User user);
}